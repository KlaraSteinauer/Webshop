package com.webshop.webshop.enums;

public enum Role {
    ADMIN, CUSTOMER, ANONYMOUS;
}
