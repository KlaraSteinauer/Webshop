package com.webshop.webshop.enums;

public enum OrderStatus {
    CANCELLED, ORDERED, SHIPPED;
}
